import { createBrowserRouter } from "react-router";
import HomePage from "./pages/HomePage";
import BookingPage from "./pages/BookingPage";
import ConfirmationPage from "./pages/ConfirmationPage";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: HomePage,
  },
  {
    path: "/booking",
    Component: BookingPage,
  },
  {
    path: "/confirmation",
    Component: ConfirmationPage,
  },
]);
