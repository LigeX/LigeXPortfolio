import { useNavigate } from "react-router";

export default function CancelPage() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-[#FAFAF8] flex items-center justify-center px-6">
      <div className="max-w-md w-full bg-white border border-black/[0.06] rounded-lg p-8 text-center">

        <h1 className="text-3xl mb-4">
          Cancel Appointment
        </h1>

        <p className="text-[#888880] mb-6">
          Are you sure you want to cancel your appointment?
        </p>

        <div className="flex gap-3 justify-center">

          <button
            onClick={() => navigate(-1)}
            className="px-5 py-3 border rounded-md"
          >
            Keep Appointment
          </button>

          <button
            onClick={() => navigate('/cancel-success')}
            className="px-5 py-3 bg-red-500 text-white rounded-md"
          >
            Confirm Cancellation
          </button>

        </div>
      </div>
    </div>
  );
}