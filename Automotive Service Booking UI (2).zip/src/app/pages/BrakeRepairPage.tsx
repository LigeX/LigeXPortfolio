import { useNavigate } from "react-router";
import { ArrowLeft, ArrowRight, Check, AlertCircle } from "lucide-react";

const serif = { fontFamily: "'Instrument Serif', serif" };

const PACKAGES = [
  {
    id: "inspection",
    badge: null,
    name: "Brake Inspection",
    price: "$49",
    priceNote: "credited toward repair",
    duration: "~30 min",
    summary:
      "A thorough assessment of your entire brake system. We measure pad thickness, check rotor condition, test fluid quality, and inspect calipers — then hand you a written report with no obligation to proceed.",
    includes: [
      "Pad thickness measurement (all 4 corners)",
      "Rotor surface and run-out check",
      "Brake fluid condition & level",
      "Caliper operation and slide pins",
      "Parking brake function",
      "Written condition report",
    ],
    cta: "Book inspection",
    accent: false,
  },
  {
    id: "pads",
    badge: "Most common",
    name: "Brake Pad Replacement",
    price: "$149",
    priceNote: "per axle, parts included",
    duration: "~1.5 hrs",
    summary:
      "OEM-equivalent pads fitted on one or both axles. Includes a rotor re-surface where the surface is within spec — keeping your stopping distance sharp without unnecessary cost.",
    includes: [
      "Premium OEM-equivalent brake pads",
      "Rotor de-glaze and re-surface (if in spec)",
      "Caliper slide pin lubrication",
      "Brake dust shield inspection",
      "Road test on completion",
      "12-month / 12,000-mile warranty",
    ],
    cta: "Book pad replacement",
    accent: true,
  },
  {
    id: "full",
    badge: null,
    name: "Full Brake Repair",
    price: "$289",
    priceNote: "per axle, all parts included",
    duration: "~2.5 hrs",
    summary:
      "Complete axle overhaul — new pads, new rotors, caliper service, and fresh brake fluid. The right choice when inspection reveals rotor wear beyond the minimum thickness or uneven scoring.",
    includes: [
      "New premium brake pads",
      "New brake rotors (both sides of axle)",
      "Caliper clean, inspect & re-grease",
      "Brake fluid flush & refill",
      "Brake hose visual inspection",
      "Road test on completion",
      "12-month / 12,000-mile warranty",
    ],
    cta: "Book full repair",
    accent: false,
  },
];

const SIGNS = [
  "Squealing or grinding when braking",
  "Longer stopping distances than usual",
  "Steering wheel pulling to one side",
  "Vibration through the pedal or wheel",
  "Brake warning light illuminated",
  "Soft or spongy pedal feel",
];

export default function BrakeRepairPage() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-[#FAFAF8] text-[#1C1C1A]" style={{ fontFamily: "'Inter', sans-serif" }}>

      {/* Header */}
      <header className="fixed top-0 left-0 right-0 z-50 bg-[#FAFAF8]/90 backdrop-blur-md border-b border-black/[0.06]">
        <div className="max-w-6xl mx-auto px-6 h-16 flex items-center justify-between">
          <a href="/" style={serif} className="text-[#1C1C1A] text-lg">
            Smart Auto Care
          </a>
          <button
            onClick={() => navigate("/")}
            className="flex items-center gap-1.5 text-sm text-[#888880] hover:text-[#1C1C1A] transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
            Back
          </button>
        </div>
      </header>

      <div className="pt-28 pb-24 px-6">
        <div className="max-w-6xl mx-auto">

          {/* Page header */}
          <div className="max-w-2xl mb-20">
            <p className="text-sm text-[#7A9E82] tracking-widest uppercase mb-5">
              Brake repair · Pricing
            </p>
            <h1
              className="text-[#1C1C1A] leading-[1.08] mb-6"
              style={{ ...serif, fontSize: "clamp(2.5rem, 5vw, 4rem)" }}
            >
              Know exactly what
              <br />
              you're paying for.
            </h1>
            <p className="text-[#888880] text-lg leading-relaxed">
              Three clear options — no bundled extras, no surprise line items.
              Every price includes parts, labour, and a written warranty.
            </p>
          </div>

          {/* Pricing cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-5 mb-24">
            {PACKAGES.map((pkg) => (
              <div
                key={pkg.id}
                className={`relative flex flex-col rounded-lg border overflow-hidden transition-shadow duration-200 hover:shadow-md ${
                  pkg.accent
                    ? "border-[#1C1C1A] bg-[#1C1C1A]"
                    : "border-black/[0.08] bg-white"
                }`}
              >
                {/* Badge */}
                {pkg.badge && (
                  <div className="absolute top-5 right-5">
                    <span className="text-xs px-2.5 py-1 rounded-full bg-[#7A9E82] text-white">
                      {pkg.badge}
                    </span>
                  </div>
                )}

                <div className="p-7 flex flex-col flex-1">
                  {/* Name */}
                  <p
                    className={`mb-6 leading-tight ${pkg.accent ? "text-white" : "text-[#1C1C1A]"}`}
                    style={{ ...serif, fontSize: "1.375rem" }}
                  >
                    {pkg.name}
                  </p>

                  {/* Price */}
                  <div className="mb-6">
                    <p
                      className={`leading-none mb-1 ${pkg.accent ? "text-white" : "text-[#1C1C1A]"}`}
                      style={{ ...serif, fontSize: "3rem" }}
                    >
                      {pkg.price}
                    </p>
                    <p className={`text-xs ${pkg.accent ? "text-white/50" : "text-[#C8C8C0]"}`}>
                      {pkg.priceNote}
                    </p>
                  </div>

                  {/* Duration */}
                  <p className={`text-xs mb-6 ${pkg.accent ? "text-white/50" : "text-[#C8C8C0]"}`}>
                    {pkg.duration}
                  </p>

                  {/* Divider */}
                  <div className={`h-px mb-6 ${pkg.accent ? "bg-white/10" : "bg-black/[0.06]"}`} />

                  {/* Summary */}
                  <p className={`text-sm leading-relaxed mb-7 ${pkg.accent ? "text-white/70" : "text-[#888880]"}`}>
                    {pkg.summary}
                  </p>

                  {/* Includes */}
                  <ul className="space-y-2.5 mb-8 flex-1">
                    {pkg.includes.map((item) => (
                      <li key={item} className="flex items-start gap-2.5 text-sm">
                        <Check
                          className={`w-3.5 h-3.5 shrink-0 mt-0.5 ${pkg.accent ? "text-[#7A9E82]" : "text-[#7A9E82]"}`}
                          strokeWidth={2.5}
                        />
                        <span className={pkg.accent ? "text-white/70" : "text-[#555550]"}>
                          {item}
                        </span>
                      </li>
                    ))}
                  </ul>

                  {/* CTA */}
                  <button
                    onClick={() => navigate("/booking")}
                    className={`w-full flex items-center justify-center gap-2 py-3.5 rounded-md text-sm transition-colors duration-200 ${
                      pkg.accent
                        ? "bg-white text-[#1C1C1A] hover:bg-[#F2F2EF]"
                        : "bg-[#1C1C1A] text-[#FAFAF8] hover:bg-[#333330]"
                    }`}
                  >
                    {pkg.cta}
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>

          {/* Warning signs section */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-start border-t border-black/[0.06] pt-20">
            <div>
              <p className="text-sm text-[#7A9E82] tracking-widest uppercase mb-5">Don't ignore these</p>
              <h2
                className="text-[#1C1C1A] leading-tight mb-6"
                style={{ ...serif, fontSize: "clamp(1.75rem, 3vw, 2.5rem)" }}
              >
                Warning signs your
                <br />
                brakes need attention.
              </h2>
              <p className="text-[#888880] leading-relaxed text-sm max-w-sm">
                Modern brake systems give you plenty of notice before they fail. If you notice
                any of the following, book an inspection — it's the most cost-effective first step.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {SIGNS.map((sign) => (
                <div
                  key={sign}
                  className="flex items-start gap-3 p-4 rounded-md bg-white border border-black/[0.06]"
                >
                  <AlertCircle className="w-4 h-4 text-[#C8A882] shrink-0 mt-0.5" />
                  <p className="text-sm text-[#555550] leading-snug">{sign}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Bottom CTA strip */}
          <div className="mt-20 flex flex-col sm:flex-row items-center justify-between gap-6 p-8 rounded-lg bg-[#F2F2EF] border border-black/[0.04]">
            <div>
              <p className="text-sm text-[#1C1C1A] mb-1">Not sure which service you need?</p>
              <p className="text-sm text-[#888880]">
                Book a $49 inspection — we'll tell you exactly what's required, with no obligation to proceed.
              </p>
            </div>
            <button
              onClick={() => navigate("/booking")}
              className="shrink-0 flex items-center gap-2 px-7 py-3.5 bg-[#1C1C1A] text-[#FAFAF8] rounded-md hover:bg-[#333330] transition-colors text-sm"
            >
              Start with an inspection
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>

        </div>
      </div>
    </div>
  );
}
