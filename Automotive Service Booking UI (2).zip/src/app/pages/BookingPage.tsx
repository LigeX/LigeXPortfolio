import { useState, useEffect } from "react";
import { useNavigate, useSearchParams } from "react-router";
import { ArrowLeft, ArrowRight, Check, ChevronLeft, ChevronRight, User } from "lucide-react";
import { SERVICES, type Package } from "../data/services";

const serif = { fontFamily: "'Instrument Serif', serif" };
const MONTHS = ["January","February","March","April","May","June","July","August","September","October","November","December"];
const DAYS = ["Su","Mo","Tu","We","Th","Fr","Sa"];
const TIME_SLOTS = ["8:00 AM","9:00 AM","10:00 AM","11:00 AM","12:00 PM","1:00 PM","2:00 PM","3:00 PM","4:00 PM","5:00 PM"];

function MiniCalendar({ selected, onSelect }: { selected: Date | null; onSelect: (d: Date) => void }) {
  const today = new Date();
  const [view, setView] = useState(new Date(today.getFullYear(), today.getMonth(), 1));
  const daysInMonth = new Date(view.getFullYear(), view.getMonth() + 1, 0).getDate();
  const firstDow = new Date(view.getFullYear(), view.getMonth(), 1).getDay();
  const prevMonth = () => setView(new Date(view.getFullYear(), view.getMonth() - 1, 1));
  const nextMonth = () => setView(new Date(view.getFullYear(), view.getMonth() + 1, 1));
  const isPast = (day: number) => {
    const d = new Date(view.getFullYear(), view.getMonth(), day);
    d.setHours(0,0,0,0);
    const t = new Date(); t.setHours(0,0,0,0);
    return d < t;
  };
  const isSelected = (day: number) =>
    selected &&
    selected.getFullYear() === view.getFullYear() &&
    selected.getMonth() === view.getMonth() &&
    selected.getDate() === day;
  const isToday = (day: number) =>
    today.getFullYear() === view.getFullYear() &&
    today.getMonth() === view.getMonth() &&
    today.getDate() === day;

  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <p style={{ ...serif, fontSize: "1.0625rem" }} className="text-[#1C1C1A]">
          {MONTHS[view.getMonth()]} {view.getFullYear()}
        </p>
        <div className="flex gap-1">
          <button onClick={prevMonth} className="w-7 h-7 flex items-center justify-center rounded hover:bg-[#F2F2EF] text-[#888880] hover:text-[#1C1C1A] transition-colors">
            <ChevronLeft className="w-4 h-4" />
          </button>
          <button onClick={nextMonth} className="w-7 h-7 flex items-center justify-center rounded hover:bg-[#F2F2EF] text-[#888880] hover:text-[#1C1C1A] transition-colors">
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>
      <div className="grid grid-cols-7 mb-2">
        {DAYS.map((d) => <div key={d} className="text-center text-xs text-[#C8C8C0] pb-2">{d}</div>)}
      </div>
      <div className="grid grid-cols-7 gap-y-1">
        {Array.from({ length: firstDow }).map((_, i) => <div key={`e-${i}`} />)}
        {Array.from({ length: daysInMonth }, (_, i) => i + 1).map((day) => {
          const past = isPast(day);
          const sel = isSelected(day);
          const tod = isToday(day);
          return (
            <button
              key={day}
              disabled={past}
              onClick={() => onSelect(new Date(view.getFullYear(), view.getMonth(), day))}
              className={`w-full aspect-square flex items-center justify-center text-sm rounded transition-colors duration-150
                ${past ? "text-[#D8D8D4] cursor-not-allowed" : ""}
                ${!past && !sel ? "hover:bg-[#F2F2EF] text-[#1C1C1A]" : ""}
                ${sel ? "bg-[#1C1C1A] text-[#FAFAF8]" : ""}
                ${tod && !sel ? "text-[#7A9E82]" : ""}
              `}
            >
              {day}
            </button>
          );
        })}
      </div>
    </div>
  );
}

export default function BookingPage() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();

  const initialServiceName = searchParams.get("service") ?? SERVICES[0].name;
  const initialPackageId = searchParams.get("package") ?? null;

  const [selectedServiceName, setSelectedServiceName] = useState(initialServiceName);
  const [selectedPackage, setSelectedPackage] = useState<Package | null>(null);
  const [selectedDate, setSelectedDate] = useState<Date | null>(null);
  const [selectedTime, setSelectedTime] = useState<string | null>(null);
  const [name, setName] = useState("");

  const service = SERVICES.find((s) => s.name === selectedServiceName) ?? SERVICES[0];

  // When service changes, default to the badged package or first
  useEffect(() => {
    const preferred =
      (initialPackageId && service.packages.find((p) => p.id === initialPackageId)) ||
      service.packages.find((p) => p.badge) ||
      service.packages[0];
    setSelectedPackage(preferred);
  }, [selectedServiceName]);

  const formatDate = (d: Date) =>
    d.toLocaleDateString("en-US", { weekday: "short", month: "long", day: "numeric" });

  const canConfirm = selectedPackage && selectedDate && selectedTime && name.trim().length > 1;

  const handleConfirm = () => {
    if (!canConfirm) return;
    const params = new URLSearchParams({
      name: name.trim(),
      service: service.name,
      package: selectedPackage!.name,
      price: String(selectedPackage!.price),
      date: selectedDate!.toISOString(),
      time: selectedTime!,
    });
    navigate(`/confirmation?${params.toString()}`);
  };

  return (
    <div className="min-h-screen bg-[#FAFAF8] text-[#1C1C1A]" style={{ fontFamily: "'Inter', sans-serif" }}>

      {/* Header */}
      <header className="fixed top-0 left-0 right-0 z-50 bg-[#FAFAF8]/90 backdrop-blur-md border-b border-black/[0.06]">
        <div className="max-w-6xl mx-auto px-6 h-16 flex items-center justify-between">
          <a href="/" style={serif} className="text-[#1C1C1A] text-lg">Smart Auto Care</a>
          <button onClick={() => navigate(-1)} className="flex items-center gap-1.5 text-sm text-[#888880] hover:text-[#1C1C1A] transition-colors">
            <ArrowLeft className="w-4 h-4" />Back
          </button>
        </div>
      </header>

      <div className="pt-28 pb-24 px-6">
        <div className="max-w-6xl mx-auto">

          {/* Title */}
          <div className="mb-16">
            <p className="text-sm text-[#7A9E82] tracking-widest uppercase mb-4">Book an appointment</p>
            <h1 className="text-[#1C1C1A] leading-tight" style={{ ...serif, fontSize: "clamp(2rem, 4vw, 3rem)" }}>
              Let's get your car<br />taken care of.
            </h1>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-[1fr_360px] gap-16">
            <div className="space-y-14">

              {/* Step 1 — Your name */}
              <div>
                <p className="text-xs text-[#C8C8C0] tracking-widest uppercase mb-6">01 — Your name</p>
                <div className="relative max-w-sm">
                  <User className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-[#C8C8C0]" />
                  <input
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="First name"
                    className="w-full pl-11 pr-4 py-3.5 bg-white border border-black/[0.08] rounded-md text-sm text-[#1C1C1A] placeholder-[#C8C8C0] focus:outline-none focus:border-[#1C1C1A] transition-colors"
                  />
                </div>
              </div>

              {/* Step 2 — Service */}
              <div>
                <p className="text-xs text-[#C8C8C0] tracking-widest uppercase mb-6">02 — Service</p>
                <div className="flex flex-wrap gap-2 mb-8">
                  {SERVICES.map((s) => (
                    <button
                      key={s.name}
                      onClick={() => setSelectedServiceName(s.name)}
                      className={`px-4 py-2 rounded-full text-sm border transition-all duration-150 ${
                        selectedServiceName === s.name
                          ? "bg-[#1C1C1A] text-[#FAFAF8] border-[#1C1C1A]"
                          : "bg-white border-black/[0.08] text-[#555550] hover:border-black/20"
                      }`}
                    >
                      {s.name}
                    </button>
                  ))}
                </div>

                {/* Packages for selected service */}
                <div className="space-y-2">
                  {service.packages.map((pkg) => {
                    const isActive = selectedPackage?.id === pkg.id;
                    return (
                      <button
                        key={pkg.id}
                        onClick={() => setSelectedPackage(pkg)}
                        className={`w-full text-left p-5 rounded-md border transition-all duration-150 ${
                          isActive ? "border-[#1C1C1A] bg-white" : "border-black/[0.06] bg-white/60 hover:border-black/20"
                        }`}
                      >
                        <div className="flex items-start justify-between gap-4">
                          <div className="flex items-start gap-4 flex-1 min-w-0">
                            <div className={`mt-0.5 w-4 h-4 rounded-full border flex items-center justify-center shrink-0 transition-colors ${
                              isActive ? "border-[#1C1C1A] bg-[#1C1C1A]" : "border-[#C8C8C0]"
                            }`}>
                              {isActive && <Check className="w-2.5 h-2.5 text-white" strokeWidth={3} />}
                            </div>
                            <div>
                              <div className="flex items-center gap-2 mb-1">
                                <p className="text-sm text-[#1C1C1A]">{pkg.name}</p>
                                {pkg.badge && (
                                  <span className="text-xs px-2 py-0.5 rounded-full bg-[#E8F0E9] text-[#4E7A58]">
                                    {pkg.badge}
                                  </span>
                                )}
                              </div>
                              <p className="text-xs text-[#888880] leading-relaxed">{pkg.summary}</p>
                            </div>
                          </div>
                          <div className="text-right shrink-0">
                            <p className="text-sm text-[#1C1C1A]">${pkg.price}</p>
                            <p className="text-xs text-[#C8C8C0]">{pkg.duration}</p>
                          </div>
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Step 3 — Date */}
              <div>
                <p className="text-xs text-[#C8C8C0] tracking-widest uppercase mb-6">03 — Date</p>
                <div className="bg-white border border-black/[0.06] rounded-md p-6 max-w-sm">
                  <MiniCalendar selected={selectedDate} onSelect={setSelectedDate} />
                </div>
              </div>

              {/* Step 4 — Time */}
              <div>
                <p className="text-xs text-[#C8C8C0] tracking-widest uppercase mb-6">04 — Time</p>
                <div className="grid grid-cols-4 sm:grid-cols-5 gap-2 max-w-sm">
                  {TIME_SLOTS.map((t) => (
                    <button
                      key={t}
                      onClick={() => setSelectedTime(t)}
                      className={`py-2.5 text-xs rounded-md border transition-all duration-150 ${
                        selectedTime === t
                          ? "bg-[#1C1C1A] text-[#FAFAF8] border-[#1C1C1A]"
                          : "bg-white border-black/[0.06] text-[#555550] hover:border-black/20"
                      }`}
                    >
                      {t}
                    </button>
                  ))}
                </div>
              </div>

            </div>

            {/* Sidebar summary */}
            <div>
              <div className="sticky top-24 bg-white border border-black/[0.06] rounded-md p-7">
                <p className="text-xs text-[#C8C8C0] tracking-widest uppercase mb-6">Summary</p>

                <div className="space-y-5 mb-8">
                  {/* Name */}
                  <div className="pb-5 border-b border-black/[0.06]">
                    <p className="text-xs text-[#888880] mb-1">Name</p>
                    <p className="text-sm text-[#1C1C1A]">
                      {name.trim() || <span className="text-[#C8C8C0]">Not entered</span>}
                    </p>
                  </div>

                  {/* Service + Package */}
                  <div className="pb-5 border-b border-black/[0.06]">
                    <p className="text-xs text-[#888880] mb-1">Service</p>
                    <p className="text-sm text-[#1C1C1A]">{service.name}</p>
                    {selectedPackage && (
                      <p className="text-xs text-[#888880] mt-1">{selectedPackage.name}</p>
                    )}
                  </div>

                  {/* Date */}
                  <div className="pb-5 border-b border-black/[0.06]">
                    <p className="text-xs text-[#888880] mb-1">Date</p>
                    <p className="text-sm text-[#1C1C1A]">
                      {selectedDate ? formatDate(selectedDate) : <span className="text-[#C8C8C0]">Not selected</span>}
                    </p>
                  </div>

                  {/* Time */}
                  <div className="pb-5 border-b border-black/[0.06]">
                    <p className="text-xs text-[#888880] mb-1">Time</p>
                    <p className="text-sm text-[#1C1C1A]">
                      {selectedTime ?? <span className="text-[#C8C8C0]">Not selected</span>}
                    </p>
                  </div>

                  {/* Price — updates live */}
                  <div className="flex items-end justify-between">
                    <div>
                      <p className="text-xs text-[#888880] mb-1">Total estimate</p>
                      <p className="text-xs text-[#C8C8C0]">{selectedPackage?.duration ?? "—"}</p>
                    </div>
                    <p style={{ ...serif, fontSize: "2rem" }} className="text-[#1C1C1A] leading-none">
                      {selectedPackage ? `$${selectedPackage.price}` : "—"}
                    </p>
                  </div>
                </div>

                <button
                  disabled={!canConfirm}
                  onClick={handleConfirm}
                  className={`w-full flex items-center justify-center gap-2 py-3.5 rounded-md text-sm transition-all duration-200 ${
                    canConfirm
                      ? "bg-[#1C1C1A] text-[#FAFAF8] hover:bg-[#333330]"
                      : "bg-[#F2F2EF] text-[#C8C8C0] cursor-not-allowed"
                  }`}
                >
                  Confirm appointment
                  <ArrowRight className="w-4 h-4" />
                </button>

                {!canConfirm && (
                  <p className="text-xs text-[#C8C8C0] text-center mt-3">
                    {!name.trim() ? "Enter your name to continue" :
                     !selectedDate ? "Select a date" :
                     !selectedTime ? "Select a time" : "Almost there"}
                  </p>
                )}
              </div>
            </div>

          </div>
        </div>
      </div>
    </div>
  );
}
