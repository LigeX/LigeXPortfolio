import { useNavigate } from "react-router";
import { Check } from "lucide-react";

const serif = { fontFamily: "'Instrument Serif', serif" };

export default function CancelSuccessPage() {
  const navigate = useNavigate();

  return (
    <div
      className="min-h-screen bg-[#FAFAF8] text-[#1C1C1A] flex items-center justify-center px-6"
      style={{ fontFamily: "'Inter', sans-serif" }}
    >
      <div className="max-w-lg w-full bg-white border border-black/[0.06] rounded-md p-8 text-center">
        <div className="w-14 h-14 rounded-full bg-[#E8F0E9] flex items-center justify-center mx-auto mb-6">
          <Check className="w-7 h-7 text-[#7A9E82]" />
        </div>

        <h1 className="text-4xl mb-4" style={serif}>
          Appointment Cancelled
        </h1>

        <p className="text-[#888880] leading-relaxed mb-8">
          Your appointment has been successfully cancelled. We
          hope to serve you again in the future.
        </p>

        <button
          onClick={() => navigate("/")}
          className="w-full py-3.5 bg-[#1C1C1A] text-[#FAFAF8] rounded-md hover:bg-[#333330] transition-colors"
        >
          Return Home
        </button>
      </div>
    </div>
  );
}