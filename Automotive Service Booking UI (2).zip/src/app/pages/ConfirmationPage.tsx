import { useNavigate, useSearchParams } from "react-router";
import { ArrowLeft, ArrowRight, Check, Calendar, Clock, MapPin, Phone, Mail } from "lucide-react";

const serif = { fontFamily: "'Instrument Serif', serif" };

const STEPS = [
  { title: "Reminder", detail: "We'll text you 24 hours before with a reminder and directions." },
  { title: "Check-in", detail: "Pull up to Bay 3. Hand over your keys — we'll handle the rest." },
  { title: "Live updates", detail: "Track progress via the link in your confirmation email, in real time." },
  { title: "Pick-up", detail: "We'll text when it's ready. Pay at the desk and you're on your way." },
];

export default function ConfirmationPage() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();

  const name = searchParams.get("name") || "there";
  const serviceName = searchParams.get("service") || "Service";
  const packageName = searchParams.get("package") || "";
  const price = searchParams.get("price") ? `$${searchParams.get("price")}` : "—";
  const rawDate = searchParams.get("date");
  const time = searchParams.get("time") || "—";

  const formattedDate = rawDate
    ? new Date(rawDate).toLocaleDateString("en-US", {
        weekday: "long",
        month: "long",
        day: "numeric",
        year: "numeric",
      })
    : "—";

  const shortDate = rawDate
    ? new Date(rawDate).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })
    : "—";

  const firstName = name.split(" ")[0];

  return (
    <div className="min-h-screen bg-[#FAFAF8] text-[#1C1C1A]" style={{ fontFamily: "'Inter', sans-serif" }}>

      {/* Header */}
      <header className="fixed top-0 left-0 right-0 z-50 bg-[#FAFAF8]/90 backdrop-blur-md border-b border-black/[0.06]">
        <div className="max-w-6xl mx-auto px-6 h-16 flex items-center justify-between">
          <a href="/" style={serif} className="text-[#1C1C1A] text-lg">Smart Auto Care</a>
          <button onClick={() => navigate("/")} className="flex items-center gap-1.5 text-sm text-[#888880] hover:text-[#1C1C1A] transition-colors">
            <ArrowLeft className="w-4 h-4" />Home
          </button>
        </div>
      </header>

      <div className="pt-28 pb-24 px-6">
        <div className="max-w-2xl mx-auto">

          {/* Success mark */}
          <div className="flex flex-col items-center text-center mb-16">
            <div className="w-14 h-14 rounded-full bg-[#E8F0E9] flex items-center justify-center mb-6">
              <Check className="w-7 h-7 text-[#7A9E82]" strokeWidth={2.5} />
            </div>
            <p className="text-sm text-[#7A9E82] tracking-widest uppercase mb-5">Confirmed</p>
            <h1
              className="text-[#1C1C1A] leading-tight mb-4"
              style={{ ...serif, fontSize: "clamp(2rem, 4vw, 3rem)" }}
            >
              Thank you for your<br />
              reservation, {firstName}.
            </h1>
            <p className="text-[#888880] leading-relaxed max-w-sm">
              Your appointment is confirmed. A summary has been sent to your email.
            </p>
          </div>

          {/* Confirmation card */}
          <div className="bg-white border border-black/[0.06] rounded-md overflow-hidden mb-6">

            {/* Card header */}
            <div className="px-7 py-5 border-b border-black/[0.06] flex items-center justify-between">
              <div>
                <p className="text-xs text-[#888880] mb-0.5">Confirmation number</p>
                <p className="text-sm text-[#1C1C1A] font-mono tracking-wider">SAC-2025-{Math.floor(Math.random() * 9000 + 1000)}</p>
              </div>
              <span className="text-xs px-3 py-1 rounded-full bg-[#E8F0E9] text-[#4E7A58]">Confirmed</span>
            </div>

            {/* Service highlight */}
            <div className="px-7 py-7 border-b border-black/[0.06]">
              <div className="flex items-start justify-between gap-4">
                <div>
                  <p style={{ ...serif, fontSize: "1.5rem" }} className="text-[#1C1C1A] mb-1">{serviceName}</p>
                  <p className="text-sm text-[#888880]">{packageName}</p>
                </div>
                <div className="text-right shrink-0">
                  <p style={{ ...serif, fontSize: "2rem" }} className="text-[#1C1C1A] leading-none">{price}</p>
                  <p className="text-xs text-[#C8C8C0] mt-1">estimated</p>
                </div>
              </div>
            </div>

            {/* Date / Time / Technician */}
            <div className="grid grid-cols-1 sm:grid-cols-3 divide-y sm:divide-y-0 sm:divide-x divide-black/[0.06]">
              {[
                { icon: Calendar, label: "Date", value: shortDate, sub: formattedDate.split(",")[0] },
                { icon: Clock, label: "Time", value: time, sub: "Arrive 5 min early" },
                { icon: null, label: "Technician", value: "James Rivera", sub: "ASE Certified" },
              ].map(({ icon: Icon, label, value, sub }) => (
                <div key={label} className="px-7 py-6">
                  <div className="flex items-center gap-2 mb-2">
                    {Icon && <Icon className="w-3.5 h-3.5 text-[#7A9E82]" />}
                    <p className="text-xs text-[#888880]">{label}</p>
                  </div>
                  <p className="text-sm text-[#1C1C1A] mb-0.5">{value}</p>
                  <p className="text-xs text-[#C8C8C0]">{sub}</p>
                </div>
              ))}
            </div>

            {/* Location */}
            <div className="px-7 py-6 border-t border-black/[0.06]">
              <p className="text-xs text-[#888880] mb-4">Service location</p>
              <div className="space-y-3">
                {[
                  { icon: MapPin, text: "2847 Westfield Ave, Suite 12, San Francisco, CA" },
                  { icon: Phone, text: "(415) 882-0441" },
                  { icon: Mail, text: "service@smartautocare.com" },
                ].map(({ icon: Icon, text }) => (
                  <div key={text} className="flex items-center gap-3 text-sm text-[#555550]">
                    <Icon className="w-3.5 h-3.5 text-[#7A9E82] shrink-0" />
                    {text}
                  </div>
                ))}
              </div>
            </div>

            {/* Footer */}
            <div className="px-7 py-4 border-t border-black/[0.06] bg-[#FAFAF8] flex items-center justify-between gap-4 flex-wrap">
              <p className="text-xs text-[#C8C8C0]">Free cancellation up to 24 hrs before</p>
              <button className="text-xs text-[#888880] hover:text-[#1C1C1A] transition-colors underline underline-offset-2">
                Add to calendar
              </button>
            </div>
          </div>

          {/* What to expect */}
          <div className="bg-white border border-black/[0.06] rounded-md p-7 mb-8">
            <p className="text-xs text-[#C8C8C0] tracking-widest uppercase mb-6">What to expect</p>
            <div className="space-y-6">
              {STEPS.map((step, i) => (
                <div key={step.title} className="flex items-start gap-4">
                  <div className="w-6 h-6 rounded-full border border-[#E8E8E4] flex items-center justify-center shrink-0 mt-0.5">
                    <span className="text-xs text-[#C8C8C0]">{i + 1}</span>
                  </div>
                  <div>
                    <p className="text-sm text-[#1C1C1A] mb-0.5">{step.title}</p>
                    <p className="text-xs text-[#888880] leading-relaxed">{step.detail}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

    {/* CTA row */}
    <div className="flex flex-col sm:flex-row gap-3">
    
            <button
              onClick={() => navigate("/")}
              className="flex-1 py-3.5 text-sm border border-black/[0.1] text-[#888880] hover:text-[#1C1C1A] hover:border-black/20 rounded-md transition-colors duration-200"
            >
              Back to home
            </button>
          
            <button
              onClick={() => navigate("/booking")}
              className="flex-1 flex items-center justify-center gap-2 py-3.5 text-sm bg-[#1C1C1A] text-[#FAFAF8] hover:bg-[#333330] rounded-md transition-colors duration-200"
            >
              Book another service
              <ArrowRight className="w-4 h-4" />
            </button>
          
            <button
              onClick={() => navigate("/cancel")}
              className="flex-1 py-3.5 text-sm border border-red-200 text-red-500 hover:bg-red-50 rounded-md transition-colors duration-200"
            >
              Cancel appointment
            </button>
    
    </div>

        </div>
      </div>
    </div>
  );
}
