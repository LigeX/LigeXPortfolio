import { useState } from "react";
import { useNavigate } from "react-router";
import { ArrowRight, Check } from "lucide-react";
import { ImageWithFallback } from "../components/figma/ImageWithFallback";
import { SERVICES } from "../data/services";

const NAV_LINKS = ["Services", "About", "Contact"];

const STATS = [
  { value: "10,000+", label: "Customers served" },
  { value: "14 yrs", label: "In business" },
  { value: "4.9 ★", label: "Average rating" },
  { value: "Same-day", label: "Availability" },
];

const TRUST = [
  "ASE-certified technicians on every job",
  "Transparent, itemised pricing — no surprises",
  "12-month / 12,000-mile parts warranty",
  "Digital progress updates while you wait",
];

export default function HomePage() {
  const navigate = useNavigate();
  const [menuOpen, setMenuOpen] = useState(false);

  return (
    <div
      className="min-h-screen bg-[#FAFAF8] text-[#1C1C1A]"
      style={{ fontFamily: "'Inter', sans-serif" }}
    >
      {/* ── Navigation ── */}
      <header className="fixed top-0 left-0 right-0 z-50 bg-[#FAFAF8]/90 backdrop-blur-md border-b border-black/[0.06]">
        <div className="max-w-6xl mx-auto px-6 h-16 flex items-center justify-between">
          <a
            href="/"
            className="flex items-center gap-2 select-none"
          >
            <span
              className="text-[#1C1C1A] tracking-tight"
              style={{
                fontFamily: "'Instrument Serif', serif",
                fontSize: "1.25rem",
              }}
            >
              Smart Auto Care
            </span>
          </a>

          {/* Desktop nav */}
          <nav className="hidden md:flex items-center gap-8">
            {NAV_LINKS.map((l) => (
              <a
                key={l}
                href={`#${l.toLowerCase()}`}
                className="text-sm text-[#888880] hover:text-[#1C1C1A] transition-colors duration-200"
              >
                {l}
              </a>
            ))}
            <button
              onClick={() => navigate("/booking")}
              className="text-sm px-5 py-2.5 bg-[#1C1C1A] text-[#FAFAF8] rounded-md hover:bg-[#333330] transition-colors duration-200"
            >
              Book now
            </button>
          </nav>

          {/* Mobile hamburger */}
          <button
            className="md:hidden text-[#888880] hover:text-[#1C1C1A]"
            onClick={() => setMenuOpen(!menuOpen)}
            aria-label="Toggle menu"
          >
            <div className="w-5 flex flex-col gap-1.5">
              <span
                className={`block h-px bg-current transition-all duration-200 ${menuOpen ? "rotate-45 translate-y-2" : ""}`}
              />
              <span
                className={`block h-px bg-current transition-all duration-200 ${menuOpen ? "opacity-0" : ""}`}
              />
              <span
                className={`block h-px bg-current transition-all duration-200 ${menuOpen ? "-rotate-45 -translate-y-2" : ""}`}
              />
            </div>
          </button>
        </div>
        {menuOpen && (
          <div className="md:hidden border-t border-black/[0.06] bg-[#FAFAF8] px-6 py-4 flex flex-col gap-4">
            {NAV_LINKS.map((l) => (
              <a
                key={l}
                href={`#${l.toLowerCase()}`}
                className="text-sm text-[#888880] hover:text-[#1C1C1A]"
              >
                {l}
              </a>
            ))}
            <button
              onClick={() => navigate("/booking")}
              className="text-sm px-5 py-2.5 bg-[#1C1C1A] text-[#FAFAF8] rounded-md w-fit"
            >
              Book now
            </button>
          </div>
        )}
      </header>

      {/* ── Hero ── */}
      <section className="pt-40 pb-28 px-6">
        <div className="max-w-6xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          <div>
            <p className="text-sm text-[#7A9E82] tracking-widest uppercase mb-6">
              Automotive service · San Francisco
            </p>
            <h1
              className="text-[#1C1C1A] mb-8 leading-[1.1]"
              style={{
                fontFamily: "'Instrument Serif', serif",
                fontSize: "clamp(2.75rem, 5vw, 4.5rem)",
              }}
            >
              Your car,
              <br />
              <em>properly</em> cared for.
            </h1>
            <p className="text-[#888880] text-lg leading-relaxed mb-10 max-w-md">
              Honest service from certified technicians. No
              upsells, no jargon — just clear diagnostics and
              quality work, done when promised.
            </p>
            <div className="flex items-center gap-4 flex-wrap">
              <button
                onClick={() => navigate("/booking")}
                className="flex items-center gap-2 px-7 py-3.5 bg-[#1C1C1A] text-[#FAFAF8] rounded-md hover:bg-[#333330] transition-colors duration-200 text-sm"
              >
                Book an appointment
                <ArrowRight className="w-4 h-4" />
              </button>
              <a
                href="#services"
                className="text-sm text-[#888880] hover:text-[#1C1C1A] transition-colors underline underline-offset-4 decoration-[#C8C8C0]"
              >
                View all services
              </a>
            </div>
          </div>

          {/* Hero image */}
          <div className="relative hidden lg:block">
            <div className="aspect-[4/3] rounded-lg overflow-hidden bg-[#F2F2EF]">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1694889649834-91ff242d1763?w=900&h=675&fit=crop&auto=format"
                alt="Clean white car in a professional service garage"
                className="w-full h-full object-cover"
              />
            </div>
            {/* Floating stat chip */}
            <div className="absolute -bottom-6 -left-6 bg-white border border-black/[0.07] rounded-lg px-5 py-4 shadow-sm">
              <p className="text-xs text-[#888880] mb-0.5">
                Average wait time
              </p>
              <p
                className="text-[#1C1C1A]"
                style={{
                  fontFamily: "'Instrument Serif', serif",
                  fontSize: "1.5rem",
                }}
              >
                34 min
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* ── Stats strip ── */}
      <section className="border-y border-black/[0.06] py-10 px-6">
        <div className="max-w-6xl mx-auto grid grid-cols-2 md:grid-cols-4 gap-8">
          {STATS.map(({ value, label }) => (
            <div key={label}>
              <p
                className="text-[#1C1C1A] leading-none mb-1"
                style={{
                  fontFamily: "'Instrument Serif', serif",
                  fontSize: "2rem",
                }}
              >
                {value}
              </p>
              <p className="text-sm text-[#888880]">{label}</p>
            </div>
          ))}
        </div>
      </section>

      {/* ── Services ── */}
      <section id="services" className="py-28 px-6">
        <div className="max-w-6xl mx-auto">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-16">
            <div>
              <p className="text-sm text-[#7A9E82] tracking-widest uppercase mb-4">
                What we do
              </p>
              <h2
                className="text-[#1C1C1A] leading-tight"
                style={{
                  fontFamily: "'Instrument Serif', serif",
                  fontSize: "clamp(2rem, 3.5vw, 3rem)",
                }}
              >
                Services built around
                <br />
                your schedule.
              </h2>
            </div>
            <button
              onClick={() => navigate("/booking")}
              className="text-sm text-[#888880] hover:text-[#1C1C1A] transition-colors flex items-center gap-1.5 shrink-0"
            >
              Book any service{" "}
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="divide-y divide-black/[0.06]">
            {SERVICES.map((s, i) => {
              const lowestPrice = Math.min(...s.packages.map((p) => p.price));
              const shortestDuration = s.packages[0].duration;
              return (
              <div
                key={s.slug}
                className="group grid grid-cols-1 md:grid-cols-[80px_1fr_auto] gap-4 md:gap-8 py-8 cursor-pointer"
                onClick={() => navigate(`/services/${s.slug}`)}
              >
                <p className="text-sm text-[#C8C8C0] tabular-nums">
                  0{i + 1}
                </p>
                <div>
                  <h3
                    className="text-[#1C1C1A] mb-2 group-hover:text-[#7A9E82] transition-colors duration-200"
                    style={{
                      fontFamily: "'Instrument Serif', serif",
                      fontSize: "1.375rem",
                    }}
                  >
                    {s.name}
                  </h3>
                  <p className="text-sm text-[#888880] leading-relaxed max-w-xl">
                    {s.description}
                  </p>
                </div>
                <div className="flex md:flex-col items-start md:items-end gap-4 md:gap-1">
                  <p className="text-[#1C1C1A] text-sm">
                    From ${lowestPrice}
                  </p>
                  <p className="text-xs text-[#C8C8C0]">
                    {shortestDuration}
                  </p>
                </div>
              </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* ── About / Trust ── */}
      <section id="about" className="py-28 px-6 bg-[#F2F2EF]">
        <div className="max-w-6xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-20 items-center">
          <div className="relative">
            <div className="aspect-[3/4] rounded-lg overflow-hidden bg-[#E8E8E4]">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1767339736233-f4b02c41ee4a?w=720&h=960&fit=crop&auto=format"
                alt="Technician working on a car engine"
                className="w-full h-full object-cover"
              />
            </div>
            <div className="absolute top-8 -right-8 hidden lg:block bg-white border border-black/[0.07] rounded-lg px-6 py-5 shadow-sm max-w-[200px]">
              <p className="text-xs text-[#888880] mb-1">
                Years in business
              </p>
              <p
                className="text-[#1C1C1A] leading-none"
                style={{
                  fontFamily: "'Instrument Serif', serif",
                  fontSize: "3rem",
                }}
              >
                14
              </p>
            </div>
          </div>

          <div>
            <p className="text-sm text-[#7A9E82] tracking-widest uppercase mb-6">
              Why Smart Auto Care
            </p>
            <h2
              className="text-[#1C1C1A] leading-tight mb-8"
              style={{
                fontFamily: "'Instrument Serif', serif",
                fontSize: "clamp(1.75rem, 3vw, 2.5rem)",
              }}
            >
              We treat your car the way
              <br />
              <em>we'd treat our own.</em>
            </h2>
            <p className="text-[#888880] leading-relaxed mb-10">
              Founded in 2011 by a pair of ASE master
              technicians who were tired of the industry's
              opacity, Smart Auto Care is built on one
              principle: tell the customer the truth, then do
              excellent work.
            </p>
            <ul className="space-y-4 mb-10">
              {TRUST.map((item) => (
                <li
                  key={item}
                  className="flex items-start gap-3 text-sm text-[#555550]"
                >
                  <Check className="w-4 h-4 text-[#7A9E82] shrink-0 mt-0.5" />
                  {item}
                </li>
              ))}
            </ul>
            <button
              onClick={() => navigate("/booking")}
              className="text-sm px-7 py-3.5 border border-[#1C1C1A] text-[#1C1C1A] rounded-md hover:bg-[#1C1C1A] hover:text-[#FAFAF8] transition-colors duration-200"
            >
              Book your first visit
            </button>
          </div>
        </div>
      </section>

      {/* ── CTA ── */}
      <section className="py-28 px-6">
        <div className="max-w-6xl mx-auto">
          <div className="bg-[#7A9E82] rounded-lg px-10 py-16 md:px-20 md:py-20 flex flex-col md:flex-row items-start md:items-center justify-between gap-10">
            <div>
              <h2
                className="text-white leading-tight mb-4"
                style={{
                  fontFamily: "'Instrument Serif', serif",
                  fontSize: "clamp(2rem, 3.5vw, 2.75rem)",
                }}
              >
                Ready when you are.
              </h2>
              <p className="text-white/70 text-base max-w-sm leading-relaxed">
                Most appointments confirmed in under two
                minutes. Same-day slots often available.
              </p>
            </div>
            <button
              onClick={() => navigate("/booking")}
              className="shrink-0 flex items-center gap-2 px-8 py-4 bg-white text-[#1C1C1A] rounded-md hover:bg-[#F2F2EF] transition-colors duration-200 text-sm"
            >
              Schedule service
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </section>

      {/* ── Footer ── */}
      <footer
        id="contact"
        className="border-t border-black/[0.06] py-14 px-6"
      >
        <div className="max-w-6xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-10 mb-12">
          <div>
            <p
              className="text-[#1C1C1A] mb-3"
              style={{
                fontFamily: "'Instrument Serif', serif",
                fontSize: "1.125rem",
              }}
            >
              Smart Auto Care
            </p>
            <p className="text-sm text-[#888880] leading-relaxed">
              2847 Westfield Ave, Suite 12
              <br />
              San Francisco, CA 94110
            </p>
          </div>
          <div>
            <p className="text-xs text-[#C8C8C0] tracking-widest uppercase mb-4">
              Contact
            </p>
            <div className="space-y-2 text-sm text-[#888880]">
              <p>(415) 882-0441</p>
              <p>hello@smartautocare.com</p>
              <p>Mon–Fri 7:30 am – 6:00 pm</p>
              <p>Sat 8:00 am – 3:00 pm</p>
            </div>
          </div>
          <div>
            <p className="text-xs text-[#C8C8C0] tracking-widest uppercase mb-4">
              Quick links
            </p>
            <div className="space-y-2 text-sm text-[#888880]">
              {[
                "Services",
                "About",
                "Book appointment",
                "Privacy policy",
              ].map((l) => (
                <p key={l}>
                  <a
                    href="#"
                    className="hover:text-[#1C1C1A] transition-colors"
                  >
                    {l}
                  </a>
                </p>
              ))}
            </div>
          </div>
        </div>
        <div className="border-t border-black/[0.06] pt-8 flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-xs text-[#C8C8C0]">
            © 2026 Smart Auto Care. All rights reserved.
          </p>
          <p className="text-xs text-[#C8C8C0]">
            Designed by Lige Xiao • University of Ottawa •
            SEG3125
          </p>
        </div>
      </footer>
    </div>
  );
}