import { useNavigate, useParams } from "react-router";
import { ArrowLeft, ArrowRight, Check } from "lucide-react";
import { getService } from "../data/services";

const serif = { fontFamily: "'Instrument Serif', serif" };

export default function ServiceDetailPage() {
  const { slug } = useParams<{ slug: string }>();
  const navigate = useNavigate();
  const service = getService(slug ?? "");

  if (!service) {
    return (
      <div className="min-h-screen bg-[#FAFAF8] flex items-center justify-center" style={{ fontFamily: "'Inter', sans-serif" }}>
        <div className="text-center">
          <p className="text-[#888880] mb-4">Service not found.</p>
          <button onClick={() => navigate("/")} className="text-sm text-[#1C1C1A] underline">Back to home</button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#FAFAF8] text-[#1C1C1A]" style={{ fontFamily: "'Inter', sans-serif" }}>

      {/* Header */}
      <header className="fixed top-0 left-0 right-0 z-50 bg-[#FAFAF8]/90 backdrop-blur-md border-b border-black/[0.06]">
        <div className="max-w-6xl mx-auto px-6 h-16 flex items-center justify-between">
          <a href="/" style={serif} className="text-[#1C1C1A] text-lg">
            Smart Auto Care
          </a>
          <button
            onClick={() => navigate(-1)}
            className="flex items-center gap-1.5 text-sm text-[#888880] hover:text-[#1C1C1A] transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
            Back
          </button>
        </div>
      </header>

      <div className="pt-28 pb-24 px-6">
        <div className="max-w-6xl mx-auto">

          {/* Page header */}
          <div className="max-w-2xl mb-20">
            <p className="text-sm text-[#7A9E82] tracking-widest uppercase mb-5">
              {service.name} · Pricing
            </p>
            <h1
              className="text-[#1C1C1A] leading-[1.08] mb-6"
              style={{ ...serif, fontSize: "clamp(2.5rem, 5vw, 4rem)" }}
            >
              {service.tagline}
            </h1>
            <p className="text-[#888880] text-lg leading-relaxed">
              {service.description}
            </p>
          </div>

          {/* Pricing cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-5 mb-24">
            {service.packages.map((pkg, i) => {
              const isAccent = !!pkg.badge;
              return (
                <div
                  key={pkg.id}
                  className={`relative flex flex-col rounded-lg border overflow-hidden transition-shadow duration-200 hover:shadow-md ${
                    isAccent ? "border-[#1C1C1A] bg-[#1C1C1A]" : "border-black/[0.08] bg-white"
                  }`}
                >
                  {pkg.badge && (
                    <div className="absolute top-5 right-5">
                      <span className="text-xs px-2.5 py-1 rounded-full bg-[#7A9E82] text-white">
                        {pkg.badge}
                      </span>
                    </div>
                  )}

                  <div className="p-7 flex flex-col flex-1">
                    {/* Order number */}
                    <p className={`text-xs mb-4 tabular-nums ${isAccent ? "text-white/30" : "text-[#D8D8D4]"}`}>
                      0{i + 1}
                    </p>

                    {/* Name */}
                    <p
                      className={`mb-6 leading-tight ${isAccent ? "text-white" : "text-[#1C1C1A]"}`}
                      style={{ ...serif, fontSize: "1.375rem" }}
                    >
                      {pkg.name}
                    </p>

                    {/* Price */}
                    <div className="mb-2">
                      <p
                        className={`leading-none ${isAccent ? "text-white" : "text-[#1C1C1A]"}`}
                        style={{ ...serif, fontSize: "3rem" }}
                      >
                        ${pkg.price}
                      </p>
                    </div>
                    <p className={`text-xs mb-6 ${isAccent ? "text-white/40" : "text-[#C8C8C0]"}`}>
                      {pkg.duration} · parts & labour included
                    </p>

                    <div className={`h-px mb-6 ${isAccent ? "bg-white/10" : "bg-black/[0.06]"}`} />

                    {/* Summary */}
                    <p className={`text-sm leading-relaxed mb-7 ${isAccent ? "text-white/60" : "text-[#888880]"}`}>
                      {pkg.summary}
                    </p>

                    {/* Includes */}
                    <ul className="space-y-2.5 mb-8 flex-1">
                      {pkg.includes.map((item) => (
                        <li key={item} className="flex items-start gap-2.5 text-sm">
                          <Check className="w-3.5 h-3.5 shrink-0 mt-0.5 text-[#7A9E82]" strokeWidth={2.5} />
                          <span className={isAccent ? "text-white/70" : "text-[#555550]"}>{item}</span>
                        </li>
                      ))}
                    </ul>

                    {/* CTA */}
                    <button
                      onClick={() =>
                        navigate(`/booking?service=${encodeURIComponent(service.name)}&package=${encodeURIComponent(pkg.id)}`)
                      }
                      className={`w-full flex items-center justify-center gap-2 py-3.5 rounded-md text-sm transition-colors duration-200 ${
                        isAccent
                          ? "bg-white text-[#1C1C1A] hover:bg-[#F2F2EF]"
                          : "bg-[#1C1C1A] text-[#FAFAF8] hover:bg-[#333330]"
                      }`}
                    >
                      Book — ${pkg.price}
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Bottom strip */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-6 p-8 rounded-lg bg-[#F2F2EF] border border-black/[0.04]">
            <div>
              <p className="text-sm text-[#1C1C1A] mb-1">Not sure which option fits?</p>
              <p className="text-sm text-[#888880]">
                Our technicians are happy to advise — call us or book any inspection and we'll guide you from there.
              </p>
            </div>
            <button
              onClick={() => navigate(`/booking?service=${encodeURIComponent(service.name)}`)}
              className="shrink-0 flex items-center gap-2 px-7 py-3.5 bg-[#1C1C1A] text-[#FAFAF8] rounded-md hover:bg-[#333330] transition-colors text-sm"
            >
              Book this service
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>

        </div>
      </div>
    </div>
  );
}
