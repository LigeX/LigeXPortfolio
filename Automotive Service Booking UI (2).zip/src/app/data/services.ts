export interface Package {
  id: string;
  name: string;
  price: number;
  duration: string;
  summary: string;
  includes: string[];
  badge?: string;
}

export interface Service {
  slug: string;
  name: string;
  tagline: string;
  description: string;
  packages: Package[];
}

export const SERVICES: Service[] = [
  {
    slug: "oil-change",
    name: "Oil Change",
    tagline: "Engine health starts here.",
    description:
      "A clean oil supply is the single most important thing you can do for your engine. We use manufacturer-specified grades and only premium-brand filters — and every visit includes a 21-point inspection at no extra charge.",
    packages: [
      {
        id: "conventional",
        name: "Conventional Oil Change",
        price: 49,
        duration: "~30 min",
        summary:
          "Conventional mineral oil for vehicles under 75,000 miles not requiring synthetic. Includes a new OEM-spec filter and a visual underbody check.",
        includes: [
          "Up to 5 qt conventional oil",
          "New OEM-spec oil filter",
          "Oil drain plug inspection",
          "Tyre pressure check",
          "21-point visual inspection",
          "Service interval sticker",
        ],
      },
      {
        id: "synthetic",
        name: "Full Synthetic Oil Change",
        price: 79,
        duration: "~30 min",
        badge: "Most popular",
        summary:
          "Full synthetic for better high-temperature stability, longer drain intervals, and improved fuel economy. Recommended for most vehicles manufactured after 2010.",
        includes: [
          "Up to 5 qt full synthetic oil",
          "New OEM-spec oil filter",
          "Oil drain plug and gasket inspection",
          "Tyre pressure check & top-up",
          "21-point visual inspection",
          "Fluid levels checked & topped",
          "Service interval sticker",
        ],
      },
      {
        id: "premium",
        name: "Premium Service Package",
        price: 109,
        duration: "~45 min",
        summary:
          "Full synthetic oil change plus cabin and engine air filter replacement, wiper blade inspection, and a written multi-point report. The most thorough single-visit maintenance you can book.",
        includes: [
          "Up to 5 qt full synthetic oil",
          "New OEM-spec oil filter",
          "Cabin air filter replacement",
          "Engine air filter inspection",
          "Wiper blade condition report",
          "Tyre pressure check & top-up",
          "Full fluid levels service",
          "Written 21-point condition report",
          "Service interval sticker",
        ],
      },
    ],
  },
  {
    slug: "brake-repair",
    name: "Brake Repair",
    tagline: "Stop safely. Every time.",
    description:
      "We assess the complete brake system before recommending anything. You'll receive a written report of exactly what we found and why each item matters — with no obligation to proceed.",
    packages: [
      {
        id: "inspection",
        name: "Brake Inspection",
        price: 49,
        duration: "~30 min",
        summary:
          "Thorough assessment of your entire brake system. Pad thickness, rotor condition, fluid quality, and caliper operation — with a written report and no obligation to proceed.",
        includes: [
          "Pad thickness measurement (all 4 corners)",
          "Rotor surface and run-out check",
          "Brake fluid condition & level",
          "Caliper operation and slide pins",
          "Parking brake function",
          "Written condition report",
        ],
      },
      {
        id: "pads",
        name: "Brake Pad Replacement",
        price: 149,
        duration: "~1.5 hrs",
        badge: "Most common",
        summary:
          "OEM-equivalent pads on one or both axles, plus a rotor re-surface where the surface is within spec. The right fix for squealing brakes or pads below minimum thickness.",
        includes: [
          "Premium OEM-equivalent brake pads",
          "Rotor de-glaze and re-surface (if in spec)",
          "Caliper slide pin lubrication",
          "Brake dust shield inspection",
          "Road test on completion",
          "12-month / 12,000-mile warranty",
        ],
      },
      {
        id: "full",
        name: "Full Brake Repair",
        price: 289,
        duration: "~2.5 hrs",
        summary:
          "Complete axle overhaul — new pads, new rotors, caliper service, and fresh fluid. The right choice when rotors are beyond minimum thickness or show deep scoring.",
        includes: [
          "New premium brake pads",
          "New brake rotors (both sides)",
          "Caliper clean, inspect & re-grease",
          "Brake fluid flush & refill",
          "Brake hose visual inspection",
          "Road test on completion",
          "12-month / 12,000-mile warranty",
        ],
      },
    ],
  },
  {
    slug: "tire-service",
    name: "Tire Service",
    tagline: "More life from every tyre.",
    description:
      "Even wear across all four tyres adds thousands of miles to their lifespan and keeps handling predictable in every condition. We'll flag any concerns in writing before touching anything.",
    packages: [
      {
        id: "rotation",
        name: "Tyre Rotation",
        price: 29,
        duration: "~30 min",
        summary:
          "Move tyres to their optimal positions to equalise tread wear. Recommended every 5,000–7,500 miles or at every other oil change.",
        includes: [
          "4-tyre rotation (standard pattern)",
          "Tyre pressure check & adjustment",
          "Visual tread-depth check",
          "Valve stem inspection",
          "Torque to manufacturer spec",
        ],
      },
      {
        id: "rotation-balance",
        name: "Rotation & Balance",
        price: 59,
        duration: "~45 min",
        badge: "Best value",
        summary:
          "Rotation plus computerised balancing on all four wheels. Eliminates vibration at speed and is the most effective way to extend tyre life between replacements.",
        includes: [
          "4-tyre rotation (standard pattern)",
          "Computerised dynamic balancing (all 4)",
          "Weight placement on alloy or steel rims",
          "Tyre pressure check & adjustment",
          "Tread-depth measurement report",
          "Valve stem inspection & replacement if needed",
          "Torque to manufacturer spec",
        ],
      },
      {
        id: "full",
        name: "Full Tyre Service",
        price: 99,
        duration: "~1 hr",
        summary:
          "Rotation, balancing, alignment angle check, and a written tread and sidewall condition report. The complete picture of your tyre health in one visit.",
        includes: [
          "4-tyre rotation",
          "Computerised dynamic balancing (all 4)",
          "Alignment angle measurement & report",
          "Tread-depth measurement (all 4 corners)",
          "Sidewall and bead condition check",
          "TPMS sensor function check",
          "Tyre pressure set to placard spec",
          "Written tyre health report",
        ],
      },
    ],
  },
  {
    slug: "engine-diagnostics",
    name: "Engine Diagnostics",
    tagline: "Know before you commit.",
    description:
      "A warning light or rough idle can mean dozens of different things. We use dealer-grade equipment to read every fault code and cross-reference live sensor data — then explain it in plain language, not workshop jargon.",
    packages: [
      {
        id: "scan",
        name: "Quick Scan",
        price: 49,
        duration: "~30 min",
        summary:
          "OBD-II fault code read-out with a plain-English explanation of each code and what it typically indicates. The fastest way to understand a warning light.",
        includes: [
          "OBD-II fault code retrieval",
          "Plain-language code explanation",
          "Live data snapshot (RPM, temp, O2)",
          "Verbal summary with technician",
          "Printed or emailed code report",
        ],
      },
      {
        id: "full",
        name: "Full Diagnostic",
        price: 89,
        duration: "~1 hr",
        badge: "Recommended",
        summary:
          "Deep-scan across all vehicle modules — engine, transmission, ABS, airbag, and more. Includes live data analysis to catch intermittent faults that don't always set a code.",
        includes: [
          "Full multi-module OBD scan",
          "Live sensor data analysis",
          "Freeze-frame data review",
          "Battery and charging system test",
          "Throttle body and idle check",
          "Written diagnostic report",
          "Repair cost estimate if issues found",
        ],
      },
      {
        id: "comprehensive",
        name: "Comprehensive Report",
        price: 129,
        duration: "~1.5 hrs",
        summary:
          "Everything in the Full Diagnostic plus a physical inspection of belts, hoses, vacuum lines, and connectors. Delivers a prioritised repair plan ranked by safety impact and urgency.",
        includes: [
          "Full multi-module OBD scan",
          "Live sensor data analysis",
          "Physical inspection: belts & hoses",
          "Vacuum line and connector check",
          "Fuel trim and misfire analysis",
          "Battery, alternator & starter test",
          "Prioritised written repair plan",
          "Estimated cost per repair item",
        ],
      },
    ],
  },
];

export const getService = (slug: string) => SERVICES.find((s) => s.slug === slug);
export const getServiceByName = (name: string) => SERVICES.find((s) => s.name === name);
