import { createBrowserRouter } from "react-router";
import HomePage from "./pages/HomePage";
import BookingPage from "./pages/BookingPage";
import ConfirmationPage from "./pages/ConfirmationPage";
import ServiceDetailPage from "./pages/ServiceDetailPage";
import CancelPage from "./pages/CancelPage";
import CancelSuccessPage from "./pages/CancelSuccessPage";

export const router = createBrowserRouter([
  { path: "/", Component: HomePage },
  { path: "/booking", Component: BookingPage },
  { path: "/confirmation", Component: ConfirmationPage },
  { path: "/services/:slug", Component: ServiceDetailPage },
  { path: "/cancel",Component: CancelPage,},
  { path: "/cancel-success", Component: CancelSuccessPage,},
]);
